// /app/(checkout)/cart/page.tsx
"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { useCart } from "@/hooks/useCart";
import { CartItem } from "@/types";

// Placeholder for an empty cart component or message
const EmptyCartMessage: React.FC = () => (
  <div className="text-center py-20">
    <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-24 w-24 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
    <h2 className="mt-6 text-2xl font-semibold text-gray-700">Your Cart is Empty</h2>
    <p className="mt-2 text-gray-500">Looks like you haven&apos;t added anything to your cart yet.</p>
    <Link href="/products" className="mt-6 inline-block bg-indigo-600 text-white py-3 px-8 rounded-md hover:bg-indigo-700 transition-colors">
        Start Shopping
    </Link>
  </div>
);

const CartPage: React.FC = () => {
  const { cart, updateItemQuantity, removeItemFromCart, loading, error } = useCart();

  const calculateSubtotal = () => {
    return cart.items.reduce((total, item) => {
      const price = item.product?.price || 0;
      return total + price * item.quantity;
    }, 0);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (error) {
    return <div className="text-center text-red-500 py-10">Error loading cart: {error.message}</div>;
  }

  if (cart.items.length === 0) {
    return <EmptyCartMessage />;
  }

  const placeholderImage = "/placeholder-image.png";

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-gray-800 mb-10 text-center">Your Shopping Cart</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items Section */}
        <div className="lg:col-span-2 space-y-6">
          {cart.items.map((item: CartItem) => (
            <div key={item.product_id} className="flex flex-col sm:flex-row items-center bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
              <div className="w-24 h-24 relative rounded-md overflow-hidden mb-4 sm:mb-0 sm:mr-6 flex-shrink-0">
                <Image 
                  src={item.product?.images?.[0]?.image_url || placeholderImage} 
                  alt={item.product?.name || "Product Image"}
                  layout="fill"
                  objectFit="cover"
                  onError={(e) => { e.currentTarget.srcset = placeholderImage; e.currentTarget.src = placeholderImage; }}
                />
              </div>
              <div className="flex-grow text-center sm:text-left">
                <Link href={`/app/(main)/products/${item.product_id}`} className="text-lg font-semibold text-indigo-600 hover:underline">
                  {item.product?.name || "Product Name Unavailable"}
                </Link>
                <p className="text-sm text-gray-500 mt-1">
                  Price: ${item.product?.price?.toFixed(2) || "N/A"}
                </p>
              </div>
              <div className="flex items-center space-x-3 mt-4 sm:mt-0 sm:ml-auto">
                <label htmlFor={`quantity-${item.product_id}`} className="sr-only">Quantity</label>
                <input 
                  type="number"
                  id={`quantity-${item.product_id}`}
                  min="1"
                  max={item.product?.stock_quantity || 99} // Use actual stock if available
                  value={item.quantity}
                  onChange={(e) => updateItemQuantity(item.product_id, parseInt(e.target.value, 10))}
                  className="w-16 border border-gray-300 rounded-md p-2 text-center focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button 
                  onClick={() => removeItemFromCart(item.product_id)}
                  className="text-red-500 hover:text-red-700 transition-colors p-2 rounded-md hover:bg-red-100"
                  title="Remove item"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary Section */}
        <div className="lg:col-span-1 bg-gray-50 p-8 rounded-lg shadow-md h-fit">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6">Order Summary</h2>
          <div className="space-y-3 mb-6">
            <div className="flex justify-between text-gray-700">
              <span>Subtotal</span>
              <span>${calculateSubtotal().toFixed(2)}</span>
            </div>
            {/* <div className="flex justify-between text-gray-700">
              <span>Shipping</span>
              <span className="text-green-500">FREE</span> // Or calculate shipping
            </div>
            <div className="flex justify-between text-gray-700">
              <span>Taxes</span>
              <span>Calculated at checkout</span>
            </div> */}
          </div>
          <div className="border-t border-gray-300 pt-6">
            <div className="flex justify-between text-xl font-bold text-gray-800">
              <span>Total</span>
              <span>${calculateSubtotal().toFixed(2)}</span>
            </div>
          </div>
          <Link href="/app/(checkout)/shipping" legacyBehavior>
            <a className="mt-8 block w-full bg-indigo-600 text-white text-center py-3 px-6 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
              Proceed to Checkout
            </a>
          </Link>
          <div className="mt-4 text-center">
            <Link href="/products" className="text-indigo-600 hover:underline text-sm">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;

