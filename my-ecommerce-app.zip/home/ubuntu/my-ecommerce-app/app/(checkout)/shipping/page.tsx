// /app/(checkout)/shipping/page.tsx
"use client";

import React, { useState, FormEvent, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { Address } from "@/types";
import { supabase } from "@/lib/supabaseClient";

// Simple form component for address input
interface AddressFormProps {
  address: Partial<Address>;
  onAddressChange: (field: keyof Address, value: string) => void;
  onSubmit: (e: FormEvent<HTMLFormElement>) => void;
  loading: boolean;
  title?: string;
}

const AddressForm: React.FC<AddressFormProps> = ({ address, onAddressChange, onSubmit, loading, title }) => {
  return (
    <form onSubmit={onSubmit} className="space-y-6 bg-white p-8 rounded-lg shadow-md">
      {title && <h2 className="text-2xl font-semibold text-gray-800 mb-6">{title}</h2>}
      <div>
        <label htmlFor="address_line1" className="block text-sm font-medium text-gray-700">Address Line 1</label>
        <input type="text" name="address_line1" id="address_line1" required autoComplete="street-address" value={address.address_line1 || ""} onChange={(e) => onAddressChange("address_line1", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
      </div>
      <div>
        <label htmlFor="address_line2" className="block text-sm font-medium text-gray-700">Address Line 2 (Optional)</label>
        <input type="text" name="address_line2" id="address_line2" autoComplete="address-line2" value={address.address_line2 || ""} onChange={(e) => onAddressChange("address_line2", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="city" className="block text-sm font-medium text-gray-700">City</label>
          <input type="text" name="city" id="city" required autoComplete="address-level2" value={address.city || ""} onChange={(e) => onAddressChange("city", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
        </div>
        <div>
          <label htmlFor="state_province_region" className="block text-sm font-medium text-gray-700">State / Province / Region</label>
          <input type="text" name="state_province_region" id="state_province_region" required autoComplete="address-level1" value={address.state_province_region || ""} onChange={(e) => onAddressChange("state_province_region", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="postal_code" className="block text-sm font-medium text-gray-700">Postal Code</label>
          <input type="text" name="postal_code" id="postal_code" required autoComplete="postal-code" value={address.postal_code || ""} onChange={(e) => onAddressChange("postal_code", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
        </div>
        <div>
          <label htmlFor="country" className="block text-sm font-medium text-gray-700">Country</label>
          <input type="text" name="country" id="country" required autoComplete="country-name" value={address.country || ""} onChange={(e) => onAddressChange("country", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
        </div>
      </div>
      <div>
        <button type="submit" disabled={loading} className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:bg-gray-400">
          {loading ? "Saving..." : "Continue to Payment"}
        </button>
      </div>
    </form>
  );
};

const ShippingPage: React.FC = () => {
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();
  const [shippingAddress, setShippingAddress] = useState<Partial<Address>>({});
  const [savedAddresses, setSavedAddresses] = useState<Address[]>([]);
  const [selectedSavedAddressId, setSelectedSavedAddressId] = useState<string | null>(null);
  const [formLoading, setFormLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/app/(auth)/login?redirect=/app/(checkout)/shipping");
    }
    if (user) {
      const fetchAddresses = async () => {
        const { data, error: fetchError } = await supabase
          .from("addresses")
          .select("*")
          .eq("user_id", user.id)
          .eq("address_type", "shipping");
        if (fetchError) {
          console.error("Error fetching addresses:", fetchError);
          setError("Could not load saved addresses.");
        } else {
          setSavedAddresses(data || []);
          const defaultAddress = data?.find(addr => addr.is_default);
          if (defaultAddress) {
            setSelectedSavedAddressId(defaultAddress.id);
            setShippingAddress(defaultAddress);
          }
        }
      };
      fetchAddresses();
    }
  }, [user, authLoading, router]);

  const handleAddressChange = (field: keyof Address, value: string) => {
    setShippingAddress(prev => ({ ...prev, [field]: value }));
    setSelectedSavedAddressId(null); // Clear selected saved address if typing new one
  };

  const handleSelectSavedAddress = (addressId: string) => {
    const selected = savedAddresses.find(addr => addr.id === addressId);
    if (selected) {
      setShippingAddress(selected);
      setSelectedSavedAddressId(selected.id);
    }
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    setFormLoading(true);
    setError(null);

    // Basic validation (more can be added)
    if (!shippingAddress.address_line1 || !shippingAddress.city || !shippingAddress.postal_code || !shippingAddress.country || !shippingAddress.state_province_region) {
        setError("Please fill in all required address fields.");
        setFormLoading(false);
        return;
    }

    try {
      // Save or update address in Supabase (optional, or just pass to next step)
      // For this example, we assume we are saving it and then proceeding.
      // This logic could be more complex (e.g. update if ID exists, insert if not)
      
      // Store shipping address in localStorage to pass to payment step
      localStorage.setItem("shippingAddress", JSON.stringify({...shippingAddress, user_id: user.id, address_type: "shipping"}));
      router.push("/app/(checkout)/payment");

    } catch (e: any) {
      console.error("Error saving shipping address:", e);
      setError(e.message || "Failed to save shipping address.");
    } finally {
      setFormLoading(false);
    }
  };

  if (authLoading) {
    return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-500"></div></div>;
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-gray-800 mb-10 text-center">Shipping Details</h1>
      {error && <p className="text-red-500 text-center mb-4">{error}</p>}
      
      {savedAddresses.length > 0 && (
        <div className="mb-8 bg-gray-50 p-6 rounded-lg shadow">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Use a saved address:</h3>
          <div className="space-y-3">
            {savedAddresses.map(addr => (
              <button 
                key={addr.id} 
                onClick={() => handleSelectSavedAddress(addr.id)} 
                className={`block w-full text-left p-4 border rounded-md transition-colors ${selectedSavedAddressId === addr.id ? "border-indigo-500 bg-indigo-50 ring-2 ring-indigo-500" : "border-gray-300 hover:bg-gray-100"}`}
              >
                <p className="font-medium">{addr.address_line1}, {addr.city}</p>
                <p className="text-sm text-gray-600">{addr.postal_code}, {addr.country} {addr.is_default ? "(Default)" : ""}</p>
              </button>
            ))}
          </div>
          <p className="text-center my-4 text-gray-600">Or enter a new address below:</p>
        </div>
      )}

      <AddressForm 
        address={shippingAddress} 
        onAddressChange={handleAddressChange} 
        onSubmit={handleSubmit} 
        loading={formLoading} 
        title={savedAddresses.length > 0 ? "Enter New Shipping Address" : "Enter Shipping Address"}
      />
    </div>
  );
};

export default ShippingPage;

