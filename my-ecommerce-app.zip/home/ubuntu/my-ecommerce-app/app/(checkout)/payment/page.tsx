// /app/(checkout)/payment/page.tsx
"use client";

import React, { useState, useEffect, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { useCart } from "@/hooks/useCart";
import { Address, Order } from "@/types";
import { supabase } from "@/lib/supabaseClient";

const PaymentPage: React.FC = () => {
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();
  const { cart, clearCart } = useCart(); // Assuming clearCart is available
  const [shippingAddress, setShippingAddress] = useState<Address | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string>("stripe"); // Default to stripe
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/app/(auth)/login?redirect=/app/(checkout)/payment");
    }
    if (typeof window !== "undefined") {
      const storedAddress = localStorage.getItem("shippingAddress");
      if (storedAddress) {
        setShippingAddress(JSON.parse(storedAddress));
      } else {
        // If no shipping address, redirect back to shipping page
        // router.push("/app/(checkout)/shipping");
        console.warn("No shipping address found in local storage. User might need to be redirected.");
      }
    }
    if (cart.items.length === 0 && !authLoading) {
        // If cart is empty, redirect to cart page or products page
        // router.push("/app/(checkout)/cart");
        console.warn("Cart is empty. User might need to be redirected.");
    }

  }, [user, authLoading, router, cart.items.length]);

  const calculateTotalAmount = () => {
    return cart.items.reduce((total, item) => {
      const price = item.product?.price || 0;
      return total + price * item.quantity;
    }, 0);
  };

  const handlePlaceOrder = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || !shippingAddress || cart.items.length === 0) {
      setError("User not logged in, shipping address missing, or cart is empty.");
      return;
    }
    setProcessing(true);
    setError(null);

    const totalAmount = calculateTotalAmount();

    // THIS IS A PLACEHOLDER FOR ACTUAL PAYMENT INTEGRATION (Stripe/PayPal)
    // In a real scenario, you would:
    // 1. Create a payment intent with your payment provider (e.g., Stripe on the server-side).
    // 2. Collect payment details using Stripe Elements or PayPal SDK.
    // 3. Confirm the payment.
    // 4. Only if payment is successful, create the order in your database.

    console.log("Simulating payment processing for payment method:", paymentMethod);

    // Simulate successful payment for now
    try {
      // Create order in Supabase
      const { data: orderData, error: orderError } = await supabase
        .from("orders")
        .insert({
          user_id: user.id,
          total_amount: totalAmount,
          status: "processing", // Or "pending_payment" until webhook confirms
          shipping_address_id: shippingAddress.id, // Assuming shippingAddress has an ID if saved
          // billing_address_id: billingAddress?.id, // If you have separate billing
          payment_gateway: paymentMethod,
          // payment_intent_id: "simulated_payment_intent_123" // From actual payment gateway
        })
        .select()
        .single();

      if (orderError) throw orderError;

      const newOrder = orderData as Order;

      // Insert order items
      const orderItems = cart.items.map(item => ({
        order_id: newOrder.id,
        product_id: item.product_id,
        quantity: item.quantity,
        price_at_purchase: item.product?.price || 0,
      }));

      const { error: itemsError } = await supabase.from("order_items").insert(orderItems);
      if (itemsError) throw itemsError;
      
      // TODO: (Important) Decrement product stock quantities here or via a database trigger/function
      // This needs to be transactional with order creation.

      // Clear the cart (localStorage and/or server-side)
      clearCart();
      localStorage.removeItem("shippingAddress");

      // Redirect to order confirmation page
      router.push(`/app/(user)/orders/${newOrder.id}?status=success`);

    } catch (e: any) {
      console.error("Error placing order:", e);
      setError(e.message || "Failed to place order. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  if (authLoading || !shippingAddress) {
    return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-500"></div></div>;
  }
  
  if (cart.items.length === 0) {
    return (
        <div className="container mx-auto px-4 py-12 text-center">
            <h1 className="text-2xl font-semibold text-gray-700 mb-4">Your cart is empty.</h1>
            <p className="text-gray-500 mb-6">Please add items to your cart before proceeding to payment.</p>
            <button onClick={() => router.push("/products")} className="bg-indigo-600 text-white py-2 px-6 rounded-md hover:bg-indigo-700">
                Shop Products
            </button>
        </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-gray-800 mb-10 text-center">Payment</h1>
      
      <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold text-gray-700 mb-6">Order Review</h2>
        
        <div className="mb-6 border-b pb-6">
          <h3 className="text-lg font-medium text-gray-800 mb-2">Shipping To:</h3>
          {shippingAddress ? (
            <div className="text-gray-600">
              <p>{shippingAddress.address_line1}</p>
              {shippingAddress.address_line2 && <p>{shippingAddress.address_line2}</p>}
              <p>{shippingAddress.city}, {shippingAddress.state_province_region} {shippingAddress.postal_code}</p>
              <p>{shippingAddress.country}</p>
            </div>
          ) : (
            <p className="text-gray-500">Shipping address not available.</p>
          )}
        </div>

        <div className="mb-6 border-b pb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-3">Items:</h3>
            {cart.items.map(item => (
                <div key={item.product_id} className="flex justify-between items-center py-2 text-sm text-gray-600">
                    <span>{item.product?.name} (x{item.quantity})</span>
                    <span>${((item.product?.price || 0) * item.quantity).toFixed(2)}</span>
                </div>
            ))}
            <div className="flex justify-between items-center pt-3 mt-2 border-t font-semibold text-gray-800">
                <span>Total</span>
                <span>${calculateTotalAmount().toFixed(2)}</span>
            </div>
        </div>

        <form onSubmit={handlePlaceOrder}>
          <h3 className="text-lg font-medium text-gray-800 mb-4">Select Payment Method:</h3>
          <div className="space-y-4 mb-8">
            <div>
              <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <input 
                  type="radio" 
                  name="paymentMethod" 
                  value="stripe"
                  checked={paymentMethod === "stripe"}
                  onChange={() => setPaymentMethod("stripe")}
                  className="form-radio h-5 w-5 text-indigo-600"
                />
                <span className="ml-3 text-gray-700 font-medium">Pay with Stripe (Credit/Debit Card)</span>
              </label>
              {paymentMethod === "stripe" && <p className="text-xs text-gray-500 mt-1 pl-8">Card details will be collected securely by Stripe on the next step (placeholder).</p>}
            </div>
            <div>
              <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <input 
                  type="radio" 
                  name="paymentMethod" 
                  value="paypal"
                  checked={paymentMethod === "paypal"}
                  onChange={() => setPaymentMethod("paypal")}
                  className="form-radio h-5 w-5 text-indigo-600"
                />
                <span className="ml-3 text-gray-700 font-medium">Pay with PayPal</span>
              </label>
              {paymentMethod === "paypal" && <p className="text-xs text-gray-500 mt-1 pl-8">You will be redirected to PayPal to complete your payment (placeholder).</p>}
            </div>
          </div>

          {error && <p className="text-red-500 text-center mb-4">{error}</p>}

          <button 
            type="submit"
            disabled={processing || !shippingAddress || cart.items.length === 0}
            className="w-full bg-green-600 text-white py-3 px-6 rounded-lg text-lg font-semibold hover:bg-green-700 transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:bg-gray-400"
          >
            {processing ? "Processing Order..." : `Place Order & Pay $${calculateTotalAmount().toFixed(2)}`}
          </button>
        </form>
        <p className="text-xs text-gray-500 mt-4 text-center">Actual payment integration with Stripe and PayPal will be implemented in a later step. This is a simulation.</p>
      </div>
    </div>
  );
};

export default PaymentPage;

