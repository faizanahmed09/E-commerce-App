// /app/(user)/orders/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabaseClient";
import { Order } from "@/types"; // Assuming Order type includes basic details
import { useRouter } from "next/navigation";

const OrdersPage: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/app/(auth)/login?redirect=/app/(user)/orders");
    }
    if (user) {
      const fetchOrders = async () => {
        setLoading(true);
        setError(null);
        try {
          const { data, error: fetchError } = await supabase
            .from("orders")
            .select(`
              id,
              created_at,
              total_amount,
              status,
              order_items ( product_id, quantity, price_at_purchase, product:products(name, images:product_images(image_url)) )
            `)
            .eq("user_id", user.id)
            .order("created_at", { ascending: false });

          if (fetchError) throw fetchError;
          setOrders(data as Order[] || []);
        } catch (e: any) {
          console.error("Error fetching orders:", e);
          setError(e.message || "Failed to fetch orders.");
        } finally {
          setLoading(false);
        }
      };
      fetchOrders();
    }
  }, [user, authLoading, router]);

  if (authLoading || loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (error) {
    return <div className="text-center text-red-500 py-10">Error: {error}</div>;
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-gray-800 mb-10 text-center">Your Orders</h1>
      {orders.length === 0 ? (
        <div className="text-center text-gray-500 py-10">
          <p>You haven&apos;t placed any orders yet.</p>
          <Link href="/products" className="mt-4 inline-block text-indigo-600 hover:underline">
            Start Shopping
          </Link>
        </div>
      ) : (
        <div className="space-y-8">
          {orders.map((order) => (
            <div key={order.id} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 pb-4 border-b">
                <div>
                  <h2 className="text-xl font-semibold text-indigo-700">
                    Order ID: <span className="font-mono text-sm">{order.id.substring(0,8)}...</span>
                  </h2>
                  <p className="text-sm text-gray-500">
                    Placed on: {new Date(order.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="mt-2 sm:mt-0 text-left sm:text-right">
                  <p className="text-lg font-semibold text-gray-800">
                    Total: ${order.total_amount.toFixed(2)}
                  </p>
                  <p className={`text-sm font-medium px-2 py-1 rounded-full inline-block mt-1 
                    ${order.status === "delivered" ? "bg-green-100 text-green-700" : 
                      order.status === "shipped" ? "bg-blue-100 text-blue-700" : 
                      order.status === "processing" ? "bg-yellow-100 text-yellow-700" : 
                      order.status === "pending_payment" ? "bg-orange-100 text-orange-700" :
                      order.status === "cancelled" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700"}
                  `}>
                    Status: {order.status.replace("_", " ").replace(/\b\w/g, l => l.toUpperCase())}
                  </p>
                </div>
              </div>
              
              {/* Display a few items from the order */}
              {order.order_items && order.order_items.length > 0 && (
                <div className="mb-4">
                  <h3 className="text-md font-medium text-gray-700 mb-2">Items:</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                    {order.order_items.slice(0, 3).map((item, index) => (
                      <div key={index} className="flex items-center text-sm text-gray-600">
                        {/* Basic image placeholder, actual image would be better */}
                        {item.product?.images?.[0]?.image_url ? (
                            <img src={item.product.images[0].image_url} alt={item.product.name || "Product image"} className="w-10 h-10 object-cover rounded mr-3"/>
                        ) : (
                            <div className="w-10 h-10 bg-gray-200 rounded mr-3 flex items-center justify-center text-gray-400 text-xs">No img</div>
                        )}
                        <span>{item.product?.name || "Product Name Unavailable"} (x{item.quantity})</span>
                        <span className="ml-auto font-medium">${(item.price_at_purchase * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                    {order.order_items.length > 3 && <p className="text-xs text-gray-500 mt-1">+ {order.order_items.length - 3} more items</p>}
                  </div>
                </div>
              )}

              <Link href={`/app/(user)/orders/${order.id}`} className="inline-block bg-indigo-500 text-white py-2 px-4 rounded-md hover:bg-indigo-600 transition-colors text-sm font-medium">
                View Order Details
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrdersPage;

