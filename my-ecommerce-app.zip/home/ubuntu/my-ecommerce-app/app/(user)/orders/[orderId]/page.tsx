// /app/(user)/orders/[orderId]/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabaseClient";
import { Order, OrderItem, Address } from "@/types";

const LoadingSpinner: React.FC = () => (
  <div className="flex justify-center items-center h-screen">
    <div className="animate-spin rounded-full h-24 w-24 border-t-4 border-b-4 border-indigo-500"></div>
  </div>
);

const OrderDetailPage: React.FC = () => {
  const params = useParams();
  const orderId = params.orderId as string;
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();

  const [order, setOrder] = useState<Order | null>(null);
  const [shippingAddressDetails, setShippingAddressDetails] = useState<Address | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push(`/app/(auth)/login?redirect=/app/(user)/orders/${orderId}`);
      return;
    }

    if (user && orderId) {
      const fetchOrderDetails = async () => {
        setLoading(true);
        setError(null);
        try {
          const { data, error: fetchError } = await supabase
            .from("orders")
            .select(`
              *,
              order_items ( *,
                product:products (id, name, sku, images:product_images(image_url, alt_text, is_primary))
              ),
              shipping_address:addresses(*)
            `)
            .eq("id", orderId)
            .eq("user_id", user.id) // Ensure user can only fetch their own order
            .single();

          if (fetchError) {
            if (fetchError.code === "PGRST116") { // PostgREST error for "single() row not found"
                 setError("Order not found or you do not have permission to view it.");
            } else {
                throw fetchError;
            }
            setOrder(null);
          } else {
            setOrder(data as Order);
            if (data && data.shipping_address) {
                setShippingAddressDetails(data.shipping_address as Address);
            } else if (data && data.shipping_address_id) {
                // Fallback if direct join didn't populate, fetch separately
                const { data: addrData, error: addrError } = await supabase
                    .from("addresses")
                    .select("*")
                    .eq("id", data.shipping_address_id)
                    .single();
                if (addrError) console.error("Error fetching shipping address separately:", addrError);
                else setShippingAddressDetails(addrData as Address);
            }
          }
        } catch (e: any) {
          console.error("Error fetching order details:", e);
          setError(e.message || "Failed to fetch order details.");
        } finally {
          setLoading(false);
        }
      };
      fetchOrderDetails();
    }
  }, [user, orderId, authLoading, router]);

  if (authLoading || loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return <div className="text-center text-red-500 py-10">Error: {error}</div>;
  }

  if (!order) {
    return <div className="text-center text-gray-500 py-10">Order not found.</div>;
  }
  
  const placeholderImage = "/placeholder-image.png";

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="bg-white p-8 rounded-lg shadow-xl">
        <div className="flex flex-col md:flex-row justify-between items-start mb-8 pb-6 border-b border-gray-200">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Order Details</h1>
            <p className="text-gray-500 mt-1">
              Order ID: <span className="font-mono text-indigo-600">{order.id}</span>
            </p>
            <p className="text-sm text-gray-500">
              Placed on: {new Date(order.created_at).toLocaleString()}
            </p>
          </div>
          <div className="mt-4 md:mt-0 md:text-right">
            <p className={`text-lg font-semibold px-3 py-1.5 rounded-full inline-block 
                ${order.status === "delivered" ? "bg-green-100 text-green-700" : 
                  order.status === "shipped" ? "bg-blue-100 text-blue-700" : 
                  order.status === "processing" ? "bg-yellow-100 text-yellow-700" : 
                  order.status === "pending_payment" ? "bg-orange-100 text-orange-700" :
                  order.status === "cancelled" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700"}
            `}>
              Status: {order.status.replace("_", " ").replace(/\b\w/g, l => l.toUpperCase())}
            </p>
            <p className="text-2xl font-bold text-gray-800 mt-2">
              Total: ${order.total_amount.toFixed(2)}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div>
            <h2 className="text-xl font-semibold text-gray-700 mb-3">Shipping Address</h2>
            {shippingAddressDetails ? (
              <div className="text-gray-600 space-y-1">
                <p>{shippingAddressDetails.address_line1}</p>
                {shippingAddressDetails.address_line2 && <p>{shippingAddressDetails.address_line2}</p>}
                <p>{shippingAddressDetails.city}, {shippingAddressDetails.state_province_region} {shippingAddressDetails.postal_code}</p>
                <p>{shippingAddressDetails.country}</p>
              </div>
            ) : (
              <p className="text-gray-500">Shipping address details not available.</p>
            )}
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-700 mb-3">Payment Information</h2>
            <p className="text-gray-600">
              Payment Method: <span className="font-medium">{order.payment_gateway ? order.payment_gateway.replace(/\b\w/g, l => l.toUpperCase()) : "N/A"}</span>
            </p>
            {order.payment_intent_id && (
                <p className="text-sm text-gray-500">Transaction ID: {order.payment_intent_id}</p>
            )}
            {/* More payment details can be added if available and appropriate */}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Order Items</h2>
          <div className="space-y-4">
            {order.order_items && order.order_items.map((item: OrderItem) => (
              <div key={item.id} className="flex flex-col sm:flex-row items-start sm:items-center p-4 border rounded-lg bg-gray-50">
                <div className="w-20 h-20 relative rounded-md overflow-hidden mb-3 sm:mb-0 sm:mr-4 flex-shrink-0 bg-gray-200">
                  <Image 
                    src={item.product?.images?.[0]?.image_url || placeholderImage} 
                    alt={item.product?.name || "Product Image"}
                    layout="fill"
                    objectFit="cover"
                    onError={(e) => { e.currentTarget.srcset = placeholderImage; e.currentTarget.src = placeholderImage; }}
                  />
                </div>
                <div className="flex-grow">
                  <Link href={`/app/(main)/products/${item.product_id}`} className="text-lg font-medium text-indigo-600 hover:underline">
                    {item.product?.name || "Product Name Unavailable"}
                  </Link>
                  {item.product?.sku && <p className="text-xs text-gray-500">SKU: {item.product.sku}</p>}
                  <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
                  <p className="text-sm text-gray-600">Price per item: ${item.price_at_purchase.toFixed(2)}</p>
                </div>
                <div className="mt-2 sm:mt-0 sm:ml-auto text-left sm:text-right">
                  <p className="text-md font-semibold text-gray-700">
                    Subtotal: ${(item.price_at_purchase * item.quantity).toFixed(2)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-10 text-center">
          <Link href="/app/(user)/orders" className="text-indigo-600 hover:underline font-medium">
            &larr; Back to All Orders
          </Link>
        </div>
      </div>
    </div>
  );
};

export default OrderDetailPage;

