// /app/(user)/profile/page.tsx
"use client";

import React, { useState, useEffect, FormEvent } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabaseClient";
import { Profile, Address } from "@/types";
import { useRouter } from "next/navigation";

// Reusable AddressForm (simplified version for profile)
interface ProfileAddressFormProps {
  address: Partial<Address>;
  onAddressChange: (field: keyof Address, value: string) => void;
  onSubmit: (e: FormEvent<HTMLFormElement>) => Promise<void>; 
  loading: boolean;
  title?: string;
  submitButtonText?: string;
}

const ProfileAddressForm: React.FC<ProfileAddressFormProps> = 
  ({ address, onAddressChange, onSubmit, loading, title, submitButtonText }) => {
  return (
    <form onSubmit={onSubmit} className="space-y-4 mt-4 border p-4 rounded-md">
      {title && <h3 className="text-lg font-medium text-gray-700 mb-2">{title}</h3>}
      <div>
        <label htmlFor={`addr_line1_${address.id || 'new'}`} className="block text-sm font-medium text-gray-700">Address Line 1</label>
        <input type="text" name="address_line1" id={`addr_line1_${address.id || 'new'}`} required value={address.address_line1 || ""} onChange={(e) => onAddressChange("address_line1", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
      </div>
      {/* Add other address fields as needed: line2, city, state, postal_code, country */}
      <div>
        <label htmlFor={`city_${address.id || 'new'}`} className="block text-sm font-medium text-gray-700">City</label>
        <input type="text" name="city" id={`city_${address.id || 'new'}`} required value={address.city || ""} onChange={(e) => onAddressChange("city", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
      </div>
      <div>
        <label htmlFor={`postal_code_${address.id || 'new'}`} className="block text-sm font-medium text-gray-700">Postal Code</label>
        <input type="text" name="postal_code" id={`postal_code_${address.id || 'new'}`} required value={address.postal_code || ""} onChange={(e) => onAddressChange("postal_code", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
      </div>
      <div>
        <label htmlFor={`country_${address.id || 'new'}`} className="block text-sm font-medium text-gray-700">Country</label>
        <input type="text" name="country" id={`country_${address.id || 'new'}`} required value={address.country || ""} onChange={(e) => onAddressChange("country", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
      </div>
      <button type="submit" disabled={loading} className="bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 disabled:bg-gray-400">
        {loading ? "Saving..." : (submitButtonText || "Save Address")}
      </button>
    </form>
  );
};

const UserProfilePage: React.FC = () => {
  const { user, profile, loading: authLoading, signOut, session } = useAuth();
  const router = useRouter();
  const [currentProfile, setCurrentProfile] = useState<Partial<Profile>>({});
  const [userAddresses, setUserAddresses] = useState<Address[]>([]);
  const [editingAddress, setEditingAddress] = useState<Partial<Address> | null>(null);
  const [isAddingNewAddress, setIsAddingNewAddress] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [pageError, setPageError] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/app/(auth)/login?redirect=/app/(user)/profile");
    }
    if (profile) {
      setCurrentProfile(profile);
    }
    if (user) {
      fetchUserAddresses(user.id);
    }
  }, [user, profile, authLoading, router]);

  const fetchUserAddresses = async (userId: string) => {
    const { data, error } = await supabase
      .from("addresses")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (error) {
      console.error("Error fetching addresses:", error);
      setPageError("Could not load addresses.");
    } else {
      setUserAddresses(data || []);
    }
  };

  const handleProfileChange = (field: keyof Profile, value: string) => {
    setCurrentProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleProfileUpdate = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || !currentProfile.id) return;
    setFormLoading(true);
    setPageError(null);
    try {
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ full_name: currentProfile.full_name, avatar_url: currentProfile.avatar_url })
        .eq("id", user.id);
      if (updateError) throw updateError;
      alert("Profile updated successfully!");
      // Optionally re-fetch profile from AuthContext or update it directly
    } catch (e: any) {
      console.error("Error updating profile:", e);
      setPageError(e.message || "Failed to update profile.");
    } finally {
      setFormLoading(false);
    }
  };

  const handleAddressFormChange = (field: keyof Address, value: string) => {
    if (editingAddress) {
      setEditingAddress(prev => ({ ...prev, [field]: value }));
    }
  };

  const handleSaveAddress = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || !editingAddress) return;
    setFormLoading(true);
    setPageError(null);

    const addressToSave = {
        ...editingAddress,
        user_id: user.id,
        // Ensure address_type is set, default to 'shipping' if not present
        address_type: editingAddress.address_type || 'shipping',
    };

    try {
      let error;
      if (editingAddress.id) { // Update existing address
        const { error: updateError } = await supabase.from("addresses").update(addressToSave).eq("id", editingAddress.id);
        error = updateError;
      } else { // Insert new address
        const { error: insertError } = await supabase.from("addresses").insert(addressToSave);
        error = insertError;
      }
      if (error) throw error;
      alert("Address saved successfully!");
      setEditingAddress(null);
      setIsAddingNewAddress(false);
      fetchUserAddresses(user.id); // Refresh addresses list
    } catch (e: any) {
      console.error("Error saving address:", e);
      setPageError(e.message || "Failed to save address.");
    } finally {
      setFormLoading(false);
    }
  };
  
  const handleDeleteAddress = async (addressId: string) => {
    if (!user || !window.confirm("Are you sure you want to delete this address?")) return;
    setFormLoading(true);
    try {
        const { error } = await supabase.from("addresses").delete().eq("id", addressId).eq("user_id", user.id);
        if (error) throw error;
        alert("Address deleted successfully!");
        fetchUserAddresses(user.id);
    } catch (e: any) {
        console.error("Error deleting address:", e);
        setPageError(e.message || "Failed to delete address.");
    } finally {
        setFormLoading(false);
    }
  };

  if (authLoading || !user || !profile) {
    return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-500"></div></div>;
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-gray-800 mb-10 text-center">Your Profile</h1>
      {pageError && <p className="text-red-500 text-center mb-4">{pageError}</p>}

      <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-lg mb-10">
        <h2 className="text-2xl font-semibold text-gray-700 mb-6">Account Details</h2>
        <form onSubmit={handleProfileUpdate} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
            <input type="email" id="email" value={user.email || ""} disabled className="mt-1 block w-full bg-gray-100 border border-gray-300 rounded-md shadow-sm py-2 px-3 sm:text-sm" />
          </div>
          <div>
            <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">Full Name</label>
            <input type="text" id="fullName" value={currentProfile.full_name || ""} onChange={(e) => handleProfileChange("full_name", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>
          <div>
            <label htmlFor="avatarUrl" className="block text-sm font-medium text-gray-700">Avatar URL (Optional)</label>
            <input type="url" id="avatarUrl" value={currentProfile.avatar_url || ""} onChange={(e) => handleProfileChange("avatar_url", e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
          </div>
          {/* TODO: Add avatar image upload functionality using Supabase Storage */}
          <button type="submit" disabled={formLoading} className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 disabled:bg-gray-400">
            {formLoading ? "Updating..." : "Update Profile"}
          </button>
        </form>
      </div>

      <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold text-gray-700 mb-6">Manage Addresses</h2>
        {userAddresses.map(addr => (
          <div key={addr.id} className="border p-4 rounded-md mb-4 flex justify-between items-start">
            <div>
              <p className="font-medium">{addr.address_line1}, {addr.city}</p>
              <p className="text-sm text-gray-600">{addr.postal_code}, {addr.country} ({addr.address_type})</p>
            </div>
            <div className="space-x-2 flex-shrink-0 ml-4">
                <button onClick={() => { setEditingAddress(addr); setIsAddingNewAddress(false); }} className="text-sm text-indigo-600 hover:underline">Edit</button>
                <button onClick={() => handleDeleteAddress(addr.id)} className="text-sm text-red-600 hover:underline" disabled={formLoading}>Delete</button>
            </div>
          </div>
        ))}
        
        {!editingAddress && !isAddingNewAddress && (
            <button onClick={() => { setEditingAddress({}); setIsAddingNewAddress(true); }} className="mt-4 bg-green-500 text-white py-2 px-4 rounded-md hover:bg-green-600">
                Add New Address
            </button>
        )}

        {(editingAddress || isAddingNewAddress) && (
          <ProfileAddressForm 
            address={editingAddress || {}} 
            onAddressChange={handleAddressFormChange} 
            onSubmit={handleSaveAddress} 
            loading={formLoading} 
            title={isAddingNewAddress ? "Add New Address" : "Edit Address"}
            submitButtonText={isAddingNewAddress ? "Add Address" : "Update Address"}
          />
        )}
         {(editingAddress || isAddingNewAddress) && (
            <button onClick={() => {setEditingAddress(null); setIsAddingNewAddress(false);}} className="mt-2 text-sm text-gray-600 hover:underline">Cancel</button>
         )}
      </div>

      <div className="max-w-2xl mx-auto mt-10 text-center">
        <button 
            onClick={async () => { await signOut(); router.push('/'); }}
            className="bg-red-500 text-white py-2 px-6 rounded-md hover:bg-red-600 transition-colors"
        >
            Sign Out
        </button>
      </div>
    </div>
  );
};

export default UserProfilePage;

