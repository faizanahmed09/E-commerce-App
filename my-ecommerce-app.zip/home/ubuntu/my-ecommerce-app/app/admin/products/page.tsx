// /app/admin/products/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { supabase } from "@/lib/supabaseClient";
import { Product } from "@/types";
import { PlusIcon, PencilSquareIcon, TrashIcon } from "@heroicons/react/24/outline";

const AdminProductsPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let query = supabase
        .from("products")
        .select(`
          id,
          name,
          price,
          sku,
          stock_quantity,
          created_at,
          category:categories (name),
          images:product_images (image_url, is_primary)
        `)
        .order("created_at", { ascending: false });

      if (searchTerm) {
        query = query.ilike("name", `%${searchTerm}%`);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      setProducts(data as Product[] || []);
    } catch (e: any) {
      console.error("Error fetching products:", e);
      setError(e.message || "Failed to fetch products.");
    } finally {
      setLoading(false);
    }
  }, [searchTerm]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const handleDeleteProduct = async (productId: string) => {
    if (!window.confirm("Are you sure you want to delete this product? This action cannot be undone.")) {
      return;
    }
    try {
      // First, delete related product images if any (or handle with CASCADE DELETE in DB)
      const { error: imageError } = await supabase.from("product_images").delete().eq("product_id", productId);
      if (imageError) {
        // Check if it is a "not found" error, which is fine if there are no images
        if (imageError.code !== "PGRST116" && imageError.code !== "23503") { // PGRST116: Row not found, 23503: foreign key violation (if images are linked elsewhere)
            throw new Error(`Failed to delete product images: ${imageError.message}`);
        }
      }

      const { error: productError } = await supabase.from("products").delete().eq("id", productId);
      if (productError) throw productError;
      
      alert("Product deleted successfully.");
      fetchProducts(); // Refresh the list
    } catch (e: any) {
      console.error("Error deleting product:", e);
      alert(`Error deleting product: ${e.message}`);
    }
  };
  
  const placeholderImage = "/placeholder-image.png";

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Manage Products</h1>
        <Link href="/app/admin/products/new" className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
          <PlusIcon className="h-5 w-5 mr-2" /> Add New Product
        </Link>
      </div>

      <div className="mb-6">
        <input 
          type="text"
          placeholder="Search products by name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      {loading && <p className="text-center text-gray-500 py-4">Loading products...</p>}
      {error && <p className="text-center text-red-500 py-4">Error: {error}</p>}

      {!loading && !error && (
        <div className="bg-white shadow-md rounded-lg overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKU</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {products.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-10 text-center text-sm text-gray-500">No products found.</td>
                </tr>
              ) : (
                products.map((product) => {
                  const primaryImage = product.images?.find(img => img.is_primary)?.image_url || product.images?.[0]?.image_url || placeholderImage;
                  return (
                    <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex-shrink-0 h-12 w-12 relative">
                            <Image src={primaryImage} alt={product.name} layout="fill" objectFit="cover" className="rounded-md" onError={(e) => { e.currentTarget.srcset = placeholderImage; e.currentTarget.src = placeholderImage; }}/>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900 truncate max-w-xs" title={product.name}>{product.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{product.sku || "N/A"}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.price.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{product.stock_quantity}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{product.category?.name || "N/A"}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-3">
                        <Link href={`/app/admin/products/${product.id}/edit`} className="text-indigo-600 hover:text-indigo-900 inline-flex items-center">
                          <PencilSquareIcon className="h-5 w-5 mr-1" /> Edit
                        </Link>
                        <button onClick={() => handleDeleteProduct(product.id)} className="text-red-600 hover:text-red-900 inline-flex items-center">
                          <TrashIcon className="h-5 w-5 mr-1" /> Delete
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}
      {/* TODO: Add pagination if many products */}
    </div>
  );
};

export default AdminProductsPage;

