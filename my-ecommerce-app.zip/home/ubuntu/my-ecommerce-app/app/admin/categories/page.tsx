// /app/admin/categories/page.tsx
"use client";

import React, { useState, useEffect, useCallback, FormEvent } from "react";
import { supabase } from "@/lib/supabaseClient";
import { Category } from "@/types";
import { PlusIcon, PencilSquareIcon, TrashIcon } from "@heroicons/react/24/outline";

interface CategoryFormData {
  id?: string;
  name: string;
  description?: string | null;
  parent_category_id?: string | null;
}

const AdminCategoriesPage: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [allCategories, setAllCategories] = useState<Category[]>([]); // For parent category dropdown
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState<CategoryFormData | null>(null);
  const [formLoading, setFormLoading] = useState(false);

  const fetchCategories = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fetchError } = await supabase
        .from("categories")
        .select("*, parent_category:categories!parent_category_id(id, name)") // Fetch parent category name
        .order("name", { ascending: true });

      if (fetchError) throw fetchError;
      setCategories(data as Category[] || []);
      setAllCategories(data as Category[] || []); // For dropdown
    } catch (e: any) {
      console.error("Error fetching categories:", e);
      setError(e.message || "Failed to fetch categories.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    if (editingCategory) {
      const { name, value } = e.target;
      setEditingCategory({
        ...editingCategory,
        [name]: value === "" && name === "parent_category_id" ? null : value, // Handle empty string for parent_category_id as null
      });
    }
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingCategory) return;
    setFormLoading(true);
    setError(null);

    try {
      const { id, ...categoryData } = editingCategory;
      let upsertError;

      if (id) { // Editing existing category
        const { error } = await supabase.from("categories").update(categoryData).eq("id", id);
        upsertError = error;
      } else { // Adding new category
        const { error } = await supabase.from("categories").insert(categoryData);
        upsertError = error;
      }

      if (upsertError) throw upsertError;
      
      alert(`Category ${id ? "updated" : "added"} successfully.`);
      setShowForm(false);
      setEditingCategory(null);
      fetchCategories(); // Refresh the list
    } catch (e: any) {
      console.error("Error saving category:", e);
      setError(e.message || "Failed to save category.");
    } finally {
      setFormLoading(false);
    }
  };

  const handleEdit = (category: Category) => {
    setEditingCategory({
      id: category.id,
      name: category.name,
      description: category.description,
      parent_category_id: category.parent_category_id,
    });
    setShowForm(true);
  };

  const handleAddNew = () => {
    setEditingCategory({ name: "", description: "", parent_category_id: null });
    setShowForm(true);
  };

  const handleDelete = async (categoryId: string) => {
    if (!window.confirm("Are you sure you want to delete this category? This may affect products linked to it.")) {
      return;
    }
    try {
      // Check if any products are using this category
      const { data: productsInCategory, error: productCheckError } = await supabase
        .from("products")
        .select("id")
        .eq("category_id", categoryId)
        .limit(1);

      if (productCheckError) throw productCheckError;
      if (productsInCategory && productsInCategory.length > 0) {
        alert("Cannot delete category: It is currently assigned to one or more products. Please reassign products first.");
        return;
      }
      
      // Check if this category is a parent to any other categories
      const { data: childCategories, error: childCheckError } = await supabase
        .from("categories")
        .select("id")
        .eq("parent_category_id", categoryId)
        .limit(1);

      if (childCheckError) throw childCheckError;
      if (childCategories && childCategories.length > 0) {
        alert("Cannot delete category: It is a parent to other subcategories. Please delete or reassign subcategories first.");
        return;
      }

      const { error: deleteError } = await supabase.from("categories").delete().eq("id", categoryId);
      if (deleteError) throw deleteError;
      
      alert("Category deleted successfully.");
      fetchCategories(); // Refresh the list
    } catch (e: any) {
      console.error("Error deleting category:", e);
      alert(`Error deleting category: ${e.message}`);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Manage Categories</h1>
        <button onClick={handleAddNew} className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
          <PlusIcon className="h-5 w-5 mr-2" /> Add New Category
        </button>
      </div>

      {showForm && editingCategory && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">
            {editingCategory.id ? "Edit Category" : "Add New Category"}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
              <input type="text" name="name" id="name" required value={editingCategory.name} onChange={handleFormChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
            </div>
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description (Optional)</label>
              <textarea name="description" id="description" value={editingCategory.description || ""} onChange={handleFormChange} rows={3} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
            </div>
            <div>
              <label htmlFor="parent_category_id" className="block text-sm font-medium text-gray-700">Parent Category (Optional)</label>
              <select name="parent_category_id" id="parent_category_id" value={editingCategory.parent_category_id || ""} onChange={handleFormChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white">
                <option value="">None (Top Level Category)</option>
                {allCategories.filter(cat => cat.id !== editingCategory.id).map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>
            {error && <p className="text-sm text-red-500">Error: {error}</p>}
            <div className="flex items-center space-x-3">
              <button type="submit" disabled={formLoading} className="bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg disabled:bg-gray-300">
                {formLoading ? "Saving..." : (editingCategory.id ? "Update Category" : "Add Category")}
              </button>
              <button type="button" onClick={() => { setShowForm(false); setEditingCategory(null); setError(null); }} className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-2 px-4 rounded-lg">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {loading && <p className="text-center text-gray-500 py-4">Loading categories...</p>}
      {!loading && !error && !showForm && (
        <div className="bg-white shadow-md rounded-lg overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parent Category</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {categories.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-10 text-center text-sm text-gray-500">No categories found.</td>
                </tr>
              ) : (
                categories.map((category) => (
                  <tr key={category.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{category.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-normal text-sm text-gray-500 max-w-md truncate" title={category.description || ""}>{category.description || "N/A"}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{category.parent_category?.name || "N/A"}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-3">
                      <button onClick={() => handleEdit(category)} className="text-indigo-600 hover:text-indigo-900 inline-flex items-center">
                        <PencilSquareIcon className="h-5 w-5 mr-1" /> Edit
                      </button>
                      <button onClick={() => handleDelete(category.id)} className="text-red-600 hover:text-red-900 inline-flex items-center">
                        <TrashIcon className="h-5 w-5 mr-1" /> Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminCategoriesPage;

