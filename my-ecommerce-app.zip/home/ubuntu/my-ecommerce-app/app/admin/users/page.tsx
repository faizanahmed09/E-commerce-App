// /app/admin/users/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabaseClient";
import { Profile } from "@/types"; // Assuming Profile includes role
import { UserCircleIcon, ShieldCheckIcon, PencilSquareIcon } from "@heroicons/react/24/outline";

interface UserWithSupabaseEmail extends Profile {
  email?: string; // To store email from auth.users
}

const AdminUsersPage: React.FC = () => {
  const [users, setUsers] = useState<UserWithSupabaseEmail[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingUser, setEditingUser] = useState<UserWithSupabaseEmail | null>(null);
  const [newRole, setNewRole] = useState<"customer" | "admin" | "">("");
  const [formLoading, setFormLoading] = useState(false);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Fetch profiles and join with auth.users to get email
      // This is a bit more complex due to Supabase RLS and potential separation
      // A view or a function in Supabase might be better for this in a production app.
      const { data: profilesData, error: profilesError } = await supabase
        .from("profiles")
        .select("*, user_email:users(email)"); // Attempt to join with users table for email
        // .select("id, full_name, avatar_url, role, created_at, updated_at, user_data:users(email)")

      if (profilesError) throw profilesError;

      let filteredUsers = profilesData?.map(p => ({
        ...p,
        // @ts-ignore
        email: p.user_email?.email || "N/A", // Adjust based on actual Supabase client response structure
      })) as UserWithSupabaseEmail[] || [];

      if (searchTerm) {
        filteredUsers = filteredUsers.filter(user => 
          user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
          user.email?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }
      
      // Sort by creation date or name
      filteredUsers.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      setUsers(filteredUsers);
    } catch (e: any) {
      console.error("Error fetching users:", e);
      setError(e.message || "Failed to fetch users.");
    } finally {
      setLoading(false);
    }
  }, [searchTerm]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleOpenEditModal = (user: UserWithSupabaseEmail) => {
    setEditingUser(user);
    setNewRole(user.role);
  };

  const handleCloseEditModal = () => {
    setEditingUser(null);
    setNewRole("");
    setError(null); // Clear form error
  };

  const handleRoleUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingUser || !newRole) return;
    setFormLoading(true);
    setError(null);
    try {
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ role: newRole })
        .eq("id", editingUser.id);
      
      if (updateError) throw updateError;

      alert("User role updated successfully.");
      handleCloseEditModal();
      fetchUsers(); // Refresh users list
    } catch (e: any) {
      console.error("Error updating user role:", e);
      setError(e.message || "Failed to update user role.");
    } finally {
      setFormLoading(false);
    }
  };

  // Note: Deleting users directly can be dangerous due to foreign key constraints (orders, etc.)
  // Usually, you would deactivate a user or handle deletion with more care.
  // This is a placeholder and should be implemented with caution.
  const handleDeleteUser = async (userId: string) => {
    if (!window.confirm("Are you sure you want to delete this user? This action is irreversible and may affect associated data like orders.")) {
      return;
    }
    alert(`User deletion for ${userId} is a placeholder. Implement with extreme caution considering data integrity.`);
    // try {
    //   // Deleting from auth.users will cascade to profiles if set up correctly
    //   // This requires admin privileges on Supabase client, usually done via an Edge Function.
    //   // const { error } = await supabase.auth.admin.deleteUser(userId);
    //   // if (error) throw error;
    //   // alert("User deleted successfully.");
    //   // fetchUsers();
    // } catch (e: any) {
    //   console.error("Error deleting user:", e);
    //   alert(`Error deleting user: ${e.message}`);
    // }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Manage Users</h1>
        {/* <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg flex items-center">
          <PlusIcon className="h-5 w-5 mr-2" /> Add New User (Manual)
        </button> */}
      </div>

      <div className="mb-6">
        <input 
          type="text"
          placeholder="Search users by name or email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      {loading && <p className="text-center text-gray-500 py-4">Loading users...</p>}
      {!loading && error && <p className="text-center text-red-500 py-4">Error: {error}</p>}

      {!loading && !error && (
        <div className="bg-white shadow-md rounded-lg overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Joined</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {users.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-sm text-gray-500">No users found.</td>
                </tr>
              ) : (
                users.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {user.avatar_url ? (
                          <img className="h-10 w-10 rounded-full mr-3 object-cover" src={user.avatar_url} alt={user.full_name || "Avatar"} />
                        ) : (
                          <UserCircleIcon className="h-10 w-10 text-gray-400 mr-3" />
                        )}
                        <div className="text-sm font-medium text-gray-900">{user.full_name || "N/A"}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.email}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                        ${user.role === "admin" ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}
                      `}>
                        {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(user.created_at).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-3">
                      <button onClick={() => handleOpenEditModal(user)} className="text-indigo-600 hover:text-indigo-900 inline-flex items-center" title="Edit Role">
                        <PencilSquareIcon className="h-5 w-5 mr-1" /> Edit Role
                      </button>
                      {/* <button onClick={() => handleDeleteUser(user.id)} className="text-red-600 hover:text-red-900 inline-flex items-center" title="Delete User (Caution!)">
                        <TrashIcon className="h-5 w-5 mr-1" /> Delete
                      </button> */}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal for editing user role */}
      {editingUser && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={handleRoleUpdate}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100 sm:mx-0 sm:h-10 sm:w-10">
                      <ShieldCheckIcon className="h-6 w-6 text-indigo-600" aria-hidden="true" />
                    </div>
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                      <h3 className="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                        Edit Role for {editingUser.full_name || editingUser.email}
                      </h3>
                      <div className="mt-4">
                        <label htmlFor="newRole" className="block text-sm font-medium text-gray-700">New Role</label>
                        <select 
                          id="newRole" 
                          name="newRole"
                          value={newRole}
                          onChange={(e) => setNewRole(e.target.value as "customer" | "admin")}
                          required
                          className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-white"
                        >
                          <option value="" disabled>Select a role</option>
                          <option value="customer">Customer</option>
                          <option value="admin">Admin</option>
                        </select>
                      </div>
                      {error && <p className="text-xs text-red-500 mt-2">Error: {error}</p>}
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button 
                    type="submit" 
                    disabled={formLoading}
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:ml-3 sm:w-auto sm:text-sm disabled:bg-gray-300"
                  >
                    {formLoading ? "Updating..." : "Update Role"}
                  </button>
                  <button 
                    type="button" 
                    onClick={handleCloseEditModal}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminUsersPage;

