// /app/admin/page.tsx
"use client";

import React from "react";
import Link from "next/link";
import { ShoppingBagIcon, TagIcon, ClipboardListIcon, UsersIcon } from "@heroicons/react/24/outline";

// Placeholder data - in a real app, this would come from Supabase
const summaryStats = {
  totalProducts: 125,
  totalCategories: 15,
  pendingOrders: 23,
  totalUsers: 340,
};

const AdminDashboardPage: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Admin Dashboard</h1>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <div className="flex items-center">
            <ShoppingBagIcon className="h-10 w-10 text-indigo-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Total Products</p>
              <p className="text-2xl font-semibold text-gray-800">{summaryStats.totalProducts}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <div className="flex items-center">
            <TagIcon className="h-10 w-10 text-green-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Total Categories</p>
              <p className="text-2xl font-semibold text-gray-800">{summaryStats.totalCategories}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <div className="flex items-center">
            <ClipboardListIcon className="h-10 w-10 text-yellow-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Pending Orders</p>
              <p className="text-2xl font-semibold text-gray-800">{summaryStats.pendingOrders}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <div className="flex items-center">
            <UsersIcon className="h-10 w-10 text-blue-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Total Users</p>
              <p className="text-2xl font-semibold text-gray-800">{summaryStats.totalUsers}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions or Links */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link href="/app/admin/products/new" className="block p-6 bg-indigo-500 text-white rounded-lg shadow-md hover:bg-indigo-600 transition-colors">
          <h2 className="text-xl font-semibold mb-2">Add New Product</h2>
          <p className="text-sm opacity-90">Quickly add a new item to your store catalog.</p>
        </Link>
        <Link href="/app/admin/orders" className="block p-6 bg-green-500 text-white rounded-lg shadow-md hover:bg-green-600 transition-colors">
          <h2 className="text-xl font-semibold mb-2">View Recent Orders</h2>
          <p className="text-sm opacity-90">Check the latest orders and manage their status.</p>
        </Link>
        <Link href="/app/admin/users" className="block p-6 bg-blue-500 text-white rounded-lg shadow-md hover:bg-blue-600 transition-colors">
          <h2 className="text-xl font-semibold mb-2">Manage Users</h2>
          <p className="text-sm opacity-90">View and manage user accounts and roles.</p>
        </Link>
      </div>

      {/* Placeholder for recent activity or reports */}
      <div className="mt-10 bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Recent Activity</h2>
        <p className="text-gray-500">This section will display recent activities or reports (e.g., new sign-ups, popular products).</p>
        {/* Example list item */}
        <ul className="mt-3 space-y-2 text-sm text-gray-600">
          <li>- New order #12345 placed by John Doe.</li>
          <li>- Product "Super Widget" stock updated.</li>
          <li>- New user registered: jane.doe@example.com</li>
        </ul>
      </div>
    </div>
  );
};

export default AdminDashboardPage;

