// /app/admin/orders/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabaseClient";
import { Order, OrderStatus } from "@/types"; // Assuming Order type includes basic details
import { EyeIcon, PencilSquareIcon } from "@heroicons/react/24/outline";

const AdminOrdersPage: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<OrderStatus | "all">("all");
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [newStatus, setNewStatus] = useState<OrderStatus | "">("");
  const [formLoading, setFormLoading] = useState(false);

  const orderStatuses: OrderStatus[] = [
    "pending_payment",
    "processing",
    "shipped",
    "delivered",
    "cancelled",
    "refunded",
  ];

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let query = supabase
        .from("orders")
        .select(`
          id,
          created_at,
          total_amount,
          status,
          user:profiles (id, full_name, email:users(email))
        `)
        .order("created_at", { ascending: false });

      if (filterStatus !== "all") {
        query = query.eq("status", filterStatus);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      // Minor transformation to get user email if profiles table doesn't directly have it
      const transformedData = data?.map(order => ({
        ...order,
        // @ts-ignore // Supabase types might be nested differently
        user_email: order.user?.email?.email || "N/A", 
        // @ts-ignore
        user_full_name: order.user?.full_name || "N/A",
      })) as Order[];
      setOrders(transformedData || []);
    } catch (e: any) {
      console.error("Error fetching orders:", e);
      setError(e.message || "Failed to fetch orders.");
    } finally {
      setLoading(false);
    }
  }, [filterStatus]);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const handleOpenEditModal = (order: Order) => {
    setEditingOrder(order);
    setNewStatus(order.status);
  };

  const handleCloseEditModal = () => {
    setEditingOrder(null);
    setNewStatus("");
    setError(null); // Clear form error
  };

  const handleStatusUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingOrder || !newStatus) return;
    setFormLoading(true);
    setError(null);
    try {
      const { error: updateError } = await supabase
        .from("orders")
        .update({ status: newStatus })
        .eq("id", editingOrder.id);
      
      if (updateError) throw updateError;

      alert("Order status updated successfully.");
      handleCloseEditModal();
      fetchOrders(); // Refresh orders list
    } catch (e: any) {
      console.error("Error updating order status:", e);
      setError(e.message || "Failed to update order status.");
    } finally {
      setFormLoading(false);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Manage Orders</h1>
        {/* Add filter dropdown */}
        <div>
          <label htmlFor="statusFilter" className="mr-2 text-sm font-medium text-gray-700">Filter by status:</label>
          <select 
            id="statusFilter" 
            name="statusFilter"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as OrderStatus | "all")}
            className="border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white"
          >
            <option value="all">All Statuses</option>
            {orderStatuses.map(status => (
              <option key={status} value={status}>{status.replace("_", " ").replace(/\b\w/g, l => l.toUpperCase())}</option>
            ))}
          </select>
        </div>
      </div>

      {loading && <p className="text-center text-gray-500 py-4">Loading orders...</p>}
      {!loading && error && <p className="text-center text-red-500 py-4">Error: {error}</p>}

      {!loading && !error && (
        <div className="bg-white shadow-md rounded-lg overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {orders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center text-sm text-gray-500">No orders found for this filter.</td>
                </tr>
              ) : (
                orders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-indigo-600" title={order.id}>
                      <Link href={`/app/(user)/orders/${order.id}`} target="_blank" rel="noopener noreferrer" className="hover:underline">
                        {order.id.substring(0, 8)}...
                      </Link>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(order.created_at).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      {/* @ts-ignore */}
                      <div>{order.user_full_name}</div>
                      {/* @ts-ignore */}
                      <div className="text-xs text-gray-500">{order.user_email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.total_amount.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                        ${order.status === "delivered" ? "bg-green-100 text-green-800" : 
                          order.status === "shipped" ? "bg-blue-100 text-blue-800" : 
                          order.status === "processing" ? "bg-yellow-100 text-yellow-800" : 
                          order.status === "pending_payment" ? "bg-orange-100 text-orange-800" :
                          order.status === "cancelled" ? "bg-red-100 text-red-800" : "bg-gray-100 text-gray-800"}
                      `}>
                        {order.status.replace("_", " ").replace(/\b\w/g, l => l.toUpperCase())}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-3">
                      <Link href={`/app/(user)/orders/${order.id}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-900 inline-flex items-center" title="View Order Details">
                        <EyeIcon className="h-5 w-5 mr-1" /> View
                      </Link>
                      <button onClick={() => handleOpenEditModal(order)} className="text-indigo-600 hover:text-indigo-900 inline-flex items-center" title="Update Status">
                        <PencilSquareIcon className="h-5 w-5 mr-1" /> Update Status
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal for editing order status */}
      {editingOrder && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={handleStatusUpdate}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                      <h3 className="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                        Update Order Status for #{editingOrder.id.substring(0,8)}...
                      </h3>
                      <div className="mt-4">
                        <label htmlFor="newStatus" className="block text-sm font-medium text-gray-700">New Status</label>
                        <select 
                          id="newStatus" 
                          name="newStatus"
                          value={newStatus}
                          onChange={(e) => setNewStatus(e.target.value as OrderStatus)}
                          required
                          className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-white"
                        >
                          <option value="" disabled>Select a status</option>
                          {orderStatuses.map(status => (
                            <option key={status} value={status}>{status.replace("_", " ").replace(/\b\w/g, l => l.toUpperCase())}</option>
                          ))}
                        </select>
                      </div>
                      {error && <p className="text-xs text-red-500 mt-2">Error: {error}</p>}
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button 
                    type="submit" 
                    disabled={formLoading}
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:ml-3 sm:w-auto sm:text-sm disabled:bg-gray-300"
                  >
                    {formLoading ? "Updating..." : "Update Status"}
                  </button>
                  <button 
                    type="button" 
                    onClick={handleCloseEditModal}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminOrdersPage;

