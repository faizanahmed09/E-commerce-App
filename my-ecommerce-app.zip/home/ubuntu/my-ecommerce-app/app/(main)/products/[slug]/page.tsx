// /app/(main)/products/[slug]/page.tsx
// Using [slug] which will be the product ID for simplicity, but could be a real slug
"use client";

import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation"; // To get the slug (product ID)
import Image from "next/image";
import { supabase } from "@/lib/supabaseClient";
import { Product, ProductImage } from "@/types";
// import { useCart } from "@/hooks/useCart"; // To be implemented

// Placeholder for a loading component
const LoadingSpinner: React.FC = () => (
  <div className="flex justify-center items-center h-screen">
    <div className="animate-spin rounded-full h-24 w-24 border-t-4 border-b-4 border-indigo-500"></div>
  </div>
);

const ProductDetailPage: React.FC = () => {
  const params = useParams();
  const productId = params.slug as string; // Assuming slug is the product ID

  const [product, setProduct] = useState<Product | null>(null);
  const [selectedImage, setSelectedImage] = useState<ProductImage | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);

  // const { addItemToCart } = useCart(); // To be implemented

  useEffect(() => {
    if (!productId) return;

    const fetchProductDetails = async () => {
      setLoading(true);
      setError(null);
      try {
        const { data, error: fetchError } = await supabase
          .from("products")
          .select(`
            *,
            category:categories (id, name),
            images:product_images (*)
          `)
          .eq("id", productId)
          .single();

        if (fetchError) throw fetchError;
        if (data) {
          setProduct(data as Product);
          if (data.images && data.images.length > 0) {
            const primaryImage = data.images.find(img => img.is_primary) || data.images[0];
            setSelectedImage(primaryImage);
          }
        } else {
          setError("Product not found.");
        }
      } catch (e: any) {
        console.error("Error fetching product details:", e);
        setError(e.message || "Failed to fetch product details.");
      } finally {
        setLoading(false);
      }
    };

    fetchProductDetails();
  }, [productId]);

  const handleAddToCart = () => {
    if (product) {
      // addItemToCart(product, quantity); // To be implemented
      alert(`${quantity} of ${product.name} added to cart! (Placeholder)`);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return <div className="text-center text-red-500 py-10">Error: {error}</div>;
  }

  if (!product) {
    return <div className="text-center text-gray-500 py-10">Product not found.</div>;
  }

  const placeholderImage = "/placeholder-image.png";
  const currentDisplayImage = selectedImage?.image_url || product.images?.[0]?.image_url || placeholderImage;

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
        {/* Image Gallery */}
        <div className="space-y-4">
          <div className="border rounded-lg shadow-lg overflow-hidden aspect-square relative bg-gray-100">
            <Image 
              src={currentDisplayImage}
              alt={selectedImage?.alt_text || product.name}
              layout="fill"
              objectFit="contain" // Use contain to see the whole image, or cover
              onError={(e) => {
                e.currentTarget.srcset = placeholderImage;
                e.currentTarget.src = placeholderImage;
              }}
            />
          </div>
          {product.images && product.images.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {product.images.map((image) => (
                <button 
                  key={image.id} 
                  onClick={() => setSelectedImage(image)}
                  className={`border rounded-md overflow-hidden aspect-square relative focus:outline-none focus:ring-2 focus:ring-indigo-500 ${selectedImage?.id === image.id ? "ring-2 ring-indigo-500" : "hover:opacity-80"}`}
                >
                  <Image 
                    src={image.image_url || placeholderImage} 
                    alt={image.alt_text || `Thumbnail of ${product.name}`}
                    layout="fill"
                    objectFit="cover"
                    onError={(e) => {
                      e.currentTarget.srcset = placeholderImage;
                      e.currentTarget.src = placeholderImage;
                    }}
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          <h1 className="text-4xl font-bold text-gray-800">{product.name}</h1>
          {product.category && (
            <p className="text-md text-gray-500">
              Category: <span className="text-indigo-600">{product.category.name}</span>
            </p>
          )}
          <p className="text-3xl font-semibold text-indigo-700">${product.price.toFixed(2)}</p>
          
          <div className="prose max-w-none text-gray-700">
            <h3 className="text-xl font-semibold mb-2 text-gray-800">Description</h3>
            <p>{product.description || "No description available."}</p>
          </div>

          {product.sku && <p className="text-sm text-gray-500">SKU: {product.sku}</p>}
          
          {product.stock_quantity !== undefined && (
             product.stock_quantity > 0 ? (
              <p className="text-sm text-green-600">In Stock ({product.stock_quantity} available)</p>
             ) : (
              <p className="text-sm text-red-500">Out of Stock</p>
             )
          )}

          {/* Quantity Selector */}
          {product.stock_quantity !== undefined && product.stock_quantity > 0 && (
            <div className="flex items-center space-x-3 my-4">
              <label htmlFor="quantity" className="font-medium text-gray-700">Quantity:</label>
              <input 
                type="number" 
                id="quantity"
                name="quantity"
                min="1"
                max={product.stock_quantity}
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, Math.min(Number(e.target.value), product.stock_quantity || 1)))} // Ensure quantity is within bounds
                className="w-20 border border-gray-300 rounded-md p-2 text-center focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          )}

          {/* Add to Cart Button */}
          <button 
            onClick={handleAddToCart}
            disabled={product.stock_quantity !== undefined && product.stock_quantity <= 0}
            className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {product.stock_quantity !== undefined && product.stock_quantity <= 0 ? "Out of Stock" : "Add to Cart"}
          </button>

          {/* TODO: Add social share buttons, wishlist button, etc. */}
        </div>
      </div>

      {/* TODO: Related Products Section */}
      {/* <div className="mt-16">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Related Products</h2>
        <p className="text-gray-600">Related products will be displayed here.</p>
      </div> */}
    </div>
  );
};

export default ProductDetailPage;

