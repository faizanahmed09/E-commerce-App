// /app/(main)/products/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { supabase } from "@/lib/supabaseClient";
import { Product } from "@/types";
import ProductCard from "@/components/products/ProductCard";
// import Link from "next/link"; // If needed for category links or pagination

// Placeholder for a loading component
const LoadingSpinner: React.FC = () => (
  <div className="flex justify-center items-center h-64">
    <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-indigo-500"></div>
  </div>
);

const ProductsPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // TODO: Add state for filters (category, price range, keyword), pagination

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      setError(null);
      try {
        // Basic fetch, ideally with pagination and filtering
        const { data, error: fetchError } = await supabase
          .from("products")
          .select(`
            *,
            category:categories (id, name),
            images:product_images (image_url, alt_text, is_primary)
          `)
          .order("created_at", { ascending: false }); // Example ordering
          // .limit(12); // Example pagination

        if (fetchError) throw fetchError;
        setProducts(data as Product[] || []);
      } catch (e: any) {
        console.error("Error fetching products:", e);
        setError(e.message || "Failed to fetch products.");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []); // TODO: Add dependencies for filters/pagination

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return <div className="text-center text-red-500 py-10">Error: {error}</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Our Products</h1>
      
      {/* TODO: Add Filters UI here (categories, price range, search input) */}
      {/* <div className="mb-8 p-4 bg-gray-100 rounded-lg">
        <h2 className="text-xl font-semibold mb-2">Filters</h2>
        <p className="text-sm text-gray-600">Filter controls will go here.</p>
      </div> */}

      {products.length === 0 ? (
        <div className="text-center text-gray-500 py-10">
          <p>No products found. Check back soon!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}

      {/* TODO: Add Pagination UI here */}
      {/* <div className="mt-12 flex justify-center">
        <p className="text-sm text-gray-600">Pagination controls will go here.</p>
      </div> */}
    </div>
  );
};

export default ProductsPage;

